package exemplopilha.java;
import javax.swing.JOptionPane;

public class ExemploPilhaJAVA {

    public static void main(String[] args) {
        Pilha p = new Pilha(5);
        int op;
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog(
            "Menu:\n"+
            "1 - Empilhar\n" + 
            "2 - Desempilhar\n" +
            "3 - Exibir os elementos\n" +
            "4 - Sair"));

            switch(op){
            case 1:
                Object valor;
                valor = JOptionPane.showInputDialog(
                "Informe o valor a ser empilhado:");
                p.empilhar(valor);
                break;
            case 2:
                JOptionPane.showMessageDialog(null, 
                        p.desempilhar());
                break;
            case 3:
                JOptionPane.showMessageDialog(null, p.ExibePilha());
                break;
            case 4:
                break;
            default:
                JOptionPane.showMessageDialog(null,
                        "Opção inválida");
            }
        }while(op!=4);
    }
    
}
