/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemplolista;

/**
 *
 * @author bruno
 */
public class IntNoSimples {
    int valor;
    IntNoSimples prox;
    IntNoSimples(int ValorNo){
        valor = ValorNo;
        prox = null;
    }
 }

