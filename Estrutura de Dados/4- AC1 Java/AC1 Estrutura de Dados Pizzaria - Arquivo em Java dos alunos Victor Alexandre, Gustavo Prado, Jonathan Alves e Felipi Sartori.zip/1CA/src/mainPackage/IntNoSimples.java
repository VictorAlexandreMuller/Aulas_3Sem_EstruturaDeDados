package mainPackage;

public class IntNoSimples {
    Pedido valor;
    IntNoSimples prox;
    IntNoSimples(Pedido ValorNo){
        valor = ValorNo;
        prox = null;
    }
 }

