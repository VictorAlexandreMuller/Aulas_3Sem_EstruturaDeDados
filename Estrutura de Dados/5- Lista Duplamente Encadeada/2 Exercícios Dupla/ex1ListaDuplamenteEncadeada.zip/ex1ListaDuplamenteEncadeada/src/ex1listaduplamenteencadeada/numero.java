package ex1listaduplamenteencadeada;

public class numero {
    private int numero;

    public numero() {
    }

    public numero(int numero) {
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    
}
