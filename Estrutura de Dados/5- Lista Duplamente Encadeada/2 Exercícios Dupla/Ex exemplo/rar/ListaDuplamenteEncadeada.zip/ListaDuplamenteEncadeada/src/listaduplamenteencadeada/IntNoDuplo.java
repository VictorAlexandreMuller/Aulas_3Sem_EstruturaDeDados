/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaduplamenteencadeada;

/**
 *
 * @author bruno
 */
public class IntNoDuplo {
    int valor;
    IntNoDuplo prox;
    IntNoDuplo ant;
 
    IntNoDuplo (int ValorNo){
    valor = ValorNo;
    prox = ant = null;
    }
}
